#include <iostream>
#include <random>
#include <algorithm>
#include <string>
#include "Utility.h"
#include "Car.h"

int main() {
    auto integers = randomIntegers();
    std::cout << "Initial: " << integers << "\n";

    // TODO: make the sequence a bitonic sequence
    std::cout << "Bitonic: " << "TODO" << "\n";
    std::vector<int>::iterator start = integers.begin();
    std::vector<int>::iterator end = integers.end();
    std::vector<int>::iterator middle = start + (integers.size() / 2);

    // Sorting first half from least to greatest
    std::sort(start, middle, [](int a, int b)
    {
        return a < b;
    });
    
    // Sorting second half from greatest to least
    std::sort(middle, end, [](int a, int b)
    {
        return a > b;
    });
    

}