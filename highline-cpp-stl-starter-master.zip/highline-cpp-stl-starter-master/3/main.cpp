#include <iostream>
#include <random>
#include <algorithm>
#include <string>
#include "Utility.h"
#include "Car.h"

int main() {
    auto cars = randomCars();
    std::cout << "Cars: " << cars << "\n";

    // TODO: print the average price and price range
    double low = cars[0].price();
    double high = cars[0].price();
    double sum = 0.0;
    for (Car& c : cars)
    {
        if (low > c.price())
        {
            low = c.price();
        }

        if (high < c.price())
        {
            high = c.price();
        }

        sum += c.price();
    }
    std::cout << "The average price is: $" << (sum / cars.size()) << "\n";

    std::cout << "The range is: $" << (high - low) << "\n";
}