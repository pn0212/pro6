#include <iostream>
#include <random>
#include <algorithm>
#include <string>
#include "Utility.h"
#include "Car.h"

int main() {
    auto cars = randomCars();
    std::cout << "Initial: " << cars << "\n";

    // TODO: print out the cars in reverse order
    std::cout << "Reversed: " << "TODO" << "\n";
    std::sort(cars.begin(), cars.end(), [](const Car& a, const Car& b) {
        return a.price() > b.price();
    });
    
    std::cout << "[ ";
    for (Car& c : cars)
    {
        std::cout << c << " ";
    }
    std::cout << "]";
}